#include "ClientSocket.h"
#include "SocketException.h"
#include <iostream>
#include <string>
#include <stdio.h>
#include <stdbool.h>
#include <cstring>
#include <stdlib.h>

int kiosk_run_1(ClientSocket* client_socket_ptr, std::string reply)
{
    char barcode[14];
    char user_id[10];

    // menu num is 1
    int menu_num = 1;
    int book_num = 0;

    printf("Book Borrow menu\n");

    printf("enter studnet ID: \n"); // ID
    std::cin >> user_id;

    printf("enter the number of books to borrow (at most 3 books): \n"); // getting number of books to borrow.
    scanf("%d", &book_num);
    if ((book_num <= 0) | (book_num >= 4)){
      printf("number of books needs to be in range 1~3\n");
      return -1; // error
    }

    std::string output = "";
    output += std::to_string(menu_num);
    output += std::to_string(book_num);
    for (int i=0; i<book_num; i++){ // reading barcode (while loop - exit when it is done)
      printf("scan book on the barcode reader...\n");
      std::cin >> barcode;
     // printf("barcode number is %s\n", barcode);
      *client_socket_ptr << barcode; // "Test message.";
      output += barcode;
    }
    output += user_id;
   // std::cout << "output is " << output << std::endl;

    *client_socket_ptr << output; // send output to server
    *client_socket_ptr >> reply;
    std::cout << reply << std::endl;
    return 1; // well terminated
}

int kiosk_run_2(ClientSocket* client_socket_ptr, std::string reply)
{
  char barcode[14];
  char user_id[10];

  // menu num is 2
  int menu_num = 2;
  int book_num = 0;
  printf("Book Return menu\n");
  printf("enter the number of books to return (at most 4 books): \n"); // getting number of books to borrow.

  std::cin >> book_num;
  if ((book_num <=  0) | (book_num >= 4)){
    printf("number of books needs to be in range 1~3\n");
    return -1; // error
  }

  std::string output = "";
  output += std::to_string(menu_num);
  output += std::to_string(book_num);

  for (int i=0; i<book_num; i++){ // reading barcode (while loop - exit when it is done)
    printf("scan book on the barcode reader...\n");

    std::cin >> barcode;
   // printf("barcode number is %s\n", barcode);
    *client_socket_ptr << barcode; // "Test message.";
    output += barcode;
  }
 // std::cout << "output is " << output << std::endl;
  *client_socket_ptr << output; // send output to server
  *client_socket_ptr >> reply;
  std::cout << reply << std::endl;
  return 1; // well terminated
}

int kiosk_run_3(ClientSocket* client_socket_ptr, std::string reply)
{
  std::string output;
  char user_id[10];
  printf("enter student ID: \n");
  std::cin >> user_id;;
  // 현재 빌린 책 list, 그리고 각 책별 반납 기한
  output += "3";
  output += user_id;
 // std::cout << "output is " << output << std::endl;
  * client_socket_ptr << output;

  std::cout << "See Current Status of " << user_id << std::endl;
  *client_socket_ptr >> reply;
  std::cout << reply << std::endl;
  return 1; // well terminated
}


int main ( int argc, int argv[] )
{
  try
    {

      ClientSocket client_socket ( "27.124.143.211", 3000 );

      std::string reply;
      int n = 1000000;
      while(n){
        try
        {
          // while (1)
          // {
          //   int menu_num = -1;

          //   printf("----- Book Management System\nenter the number of action -----\n(1: borrow, 2: return, 3: current status, 0: exit)\n");
          //   scanf("%d", &menu_num);

          //   if (menu_num == 1)
          //   {
          //       int termin_status = kiosk_run_1(&client_socket, reply);
          //       if (termin_status == -1){break;}
          //   }
          //   else if (menu_num == 2)
          //   {
          //       int termin_status = kiosk_run_2(&client_socket, reply);
          //       if (termin_status == -1){break;}
          //   }
          //   else if (menu_num == 3){
          //       int termin_status = kiosk_run_3(&client_socket, reply);
          //   }
          //   else if(menu_num == 0){
          //       printf("Terminate the Book Management System\n");
          //       break;
          //   }
          // }
        
        // std::string a = "110001964668884201911159";
        // client_socket << a;
        // client_socket >> reply;
        // n--;
        // a = "210001964668884";
        // client_socket << a;
        // client_socket >> reply;
        // n--;
        // if(n%1000000==0){
        //   std::cout<<"지나갑니다~"<<n<<"\n";
        // }
        std::string a = "3201911159";
        client_socket <<a;
        std::string reply;
        client_socket >>reply;
        //std::cout << "We received this response from the server:\n" << reply << "\n";
        n--;
        //std::cout << "We received this response from the server:\n" << reply << "\n";
        }
        catch ( SocketException& ) {break;}

        //std::cout << "We received this response from the server:\n\"" << reply << "\"\n";;

      }

    }
  catch ( SocketException& e )
    {
      std::cout << "Exception was caught:" << e.description() << "\n";
    }

  return 0;
}

