#include "ServerSocket.h"
#include "SocketException.h"
#include <string>
#include <iostream>
#include <cstdio>
#include <ctime>
#include <vector>
#include "/usr/include/mysql/mysql.h"
#include <signal.h>

using namespace std;
#define HOST "xxx.xxx.xx.xxx" //DATA SERVER IP

int check_user(MYSQL_RES* res, int user_id);
int check_book(MYSQL_RES* res, int barcode);

string rent(int user_id, int barcode, MYSQL* mysql){
    MYSQL_RES* res;
    char query[1024] = "SELECT * FROM user_info";

    if(mysql_query(mysql, query)) {
        return to_string(barcode)+ "은 대여할 수 없습니다..\n";
        exit(1);
    }
    res = mysql_store_result(mysql);

    int book = check_user(res, user_id);
    if(!book) {
        return to_string(user_id) +"는 대여를 할 수 없습니다.\n";
    }

    query[0] = '\0';
    sprintf(query, "SELECT * FROM book_info WHERE barcode=%d", barcode);

    if(mysql_query(mysql, query)) {
        return to_string(barcode) +"대여를 할 수 없습니다.\n";
        exit(1);
    }
    res = mysql_store_result(mysql);
    
    if (check_book(res, barcode)) {
        return to_string(barcode)+ "은 대여할 수 없습니다..\n";
        exit(1);
    }

    time_t now = time(NULL);
    tm* ptm = localtime(&now);

    char rent_day[64];
    strftime(rent_day, 64, "%Y-%m-%d", ptm);

    query[0] = '\0';
    
    sprintf(query, "UPDATE user_info SET book%d = %d, book%d_rent = '%s' WHERE user_id = %d",
    book, barcode, book, rent_day, user_id);

    if(mysql_query(mysql, query)) {
        return to_string(barcode)+ "은 대여할 수 없습니다..\n";
        
    }
    query[0] = '\0';
    sprintf(query, "UPDATE book_info SET status=%d, user_id=%d, rentday='%s' WHERE barcode = %d",
    1, user_id, rent_day, barcode);
    
    if(mysql_query(mysql, query)) {
        return to_string(barcode)+ "은 대여할 수 없습니다..\n";
    }
    mysql_free_result(res);
    return to_string(barcode) + "은 대여 되었습니다.\n";
}

int check_user(MYSQL_RES* res, int user_id) {
    MYSQL_ROW row;
    
    int books[3];
    int idx = -1;
    int state = 0;
    string penalty;
    int field = mysql_num_fields(res);
    int state_p = 0;

    while((row = mysql_fetch_row(res))) {
        
        int tmp = atoi(row[9]);
        if(tmp == user_id) {
            books[0] = atoi(row[3]); books[1] = atoi(row[5]); books[2] = atoi(row[7]);
            for (int i = 0; i<3; i++) {
                if(books[i] == -1) {
                    idx = i+1;
                    break;
                }
            }
            state = 1;
            
            if(row[field - 1] != NULL) {
                state_p = 1;
            }
        }
    }
    if (state == 0) {
        //printf("해당 학번이 존재하지 않아 등록이 필요합니다. ");
        return 0;
    }
    if (state_p == 1) {
        //printf("빌리신 책이 연체되었습니다. ");
        return 0;
    }
    if (idx == -1) {
        //printf("책 대여 권수를 초과합니다. ");
        return 0;
    }

    return idx;
}
int check_book(MYSQL_RES* res, int barcode) {
    MYSQL_ROW row;
    
    int books[3];
    int idx = -1;
    int state = 1;
    string penalty;
    int field = mysql_num_fields(res);
    int state_p = 0;

    while((row = mysql_fetch_row(res))) {
        int tmp = atoi(row[field - 1]);
        if(tmp == barcode) {
            state = atoi(row[5]);
            if(state != 1) {
                return 0;
            }
        }
    }
    return 1;
}

string returning(int barcode , MYSQL* mysql){ //return the query
	MYSQL_RES* sql_res1;
	string query1, query2, query3, query4;
	query1 =   "UPDATE book_info SET status = 0 WHERE barcode=" + to_string(barcode);
	query2 =   "select * from book_info WHERE barcode = " + to_string(barcode);
    if(mysql_query(mysql,query1.c_str())) {
        return("%s\n", mysql_error(mysql));
    }
    if(mysql_query(mysql,query2.c_str())) {
        return("%s\n", mysql_error(mysql));
    }
	sql_res1 = mysql_store_result(mysql);
	MYSQL_ROW   sql_row;
	string book_name;
	sql_row = mysql_fetch_row(sql_res1);
	book_name = sql_row[1];
	string test;
	test = sql_row[6];
	query3 = "select * from user_info WHERE user_id = " + test;
    if(mysql_query(mysql,query3.c_str())) {
        return("%s\n", mysql_error(mysql));
    }
    sql_res1 = mysql_store_result(mysql);
	sql_row = mysql_fetch_row(sql_res1);

	int index[] = {3,5,7};
	int temp = 0;
	for (int i : index){
		temp++;
		if(stoi(sql_row[i]) == barcode){    
            
			query4 = "UPDATE user_info SET book"+ to_string(temp) + "=-1, book"+ to_string(temp)+"_rent = null";
			mysql_query(mysql,query4.c_str());
			mysql_store_result(mysql);
			mysql_fetch_row(sql_res1);
		}
		
	}
    mysql_free_result(sql_res1);
	return "you're returning "+ book_name +"\n";
}

string check_status(int user_id , MYSQL* mysql){
    MYSQL_RES* sql_res1;
    string query1;
    string temp;
    query1 =  "select * from user_info WHERE user_id = " + to_string(user_id);
    if(mysql_query(mysql,query1.c_str())) {
        return("%s\n", mysql_error(mysql));
    }
    sql_res1 = mysql_store_result(mysql);
    MYSQL_ROW   sql_row;
    sql_row = mysql_fetch_row(sql_res1);
    temp = "당신의 총 대여 권 수는 ";
    int index[] = {3,5,7};
	int count = 0;
	for (int i : index){
        if(stoi(sql_row[i]) != -1){
            count++;
        }
    }
    temp += to_string(count);
    temp += "권입니다.\n";
    if (count ==0)
    {
        temp += " 현재 빌린 책은 없습니다.";
    }
    else{
        temp += " 현재 빌린 책은 ";
        for (int i : index){
            if(stoi(sql_row[i]) != -1){
                temp += sql_row[i];
                temp += " ";
            }
        }
        temp += "입니다.";
    }
    if(sql_row[11]==NULL){
        temp += "연체로 인한 대여 제한이 없습니다\n";
    }
    else{
        temp += "연체로 인해 ";
        temp += sql_row[11];
        temp += "까지 대여가 제한됩니다.\n";
    }
    
    mysql_free_result(sql_res1);
    return temp;
}


int main ( int argc, int argv[] )
{
	std::cout << "running....\n";
	MYSQL* connection=NULL;
	MYSQL mysql;
	MYSQL_RES* sql_res;
	MYSQL_ROW   sql_row;
    pid_t pid;
    try
    {

        ServerSocket server ( 3000 );
        int listenFD;
        int connectFD;  
        listenFD = server.listen();
        int connect_count= 0;
        while ( true ) {

            ServerSocket new_sock;
            connectFD = server.accept ( new_sock );
            //cout<<"connectFD:"<< connectFD<< endl;
            connect_count++;
            //cout<<"listenFD:"<< listenFD <<endl;
            cout<<"현재 연결된 클라이언트는 " <<connect_count<<endl;
            pid = fork();
            if(pid == 0){ 
                try{
                    close(listenFD);
                    mysql_init(&mysql);
                    connection = mysql_real_connect(&mysql, HOST, "root", "1234", "team_proj", 3306, (char*)NULL, 0);
                    if(!connection) {
                        printf("%s\n", mysql_error(&mysql));
                        exit(1);
                    }   
                    while ( true ){
                        std::string data;
                        std::string reply;
                        int num_book;
                        vector<string> barcode;

                        new_sock >> data;
                        int task;
                        //cout<< data <<endl;
                        task = stoi(data.substr(0,1));
                        string user_id;
                        if(task == 1){
                            num_book =stoi(data.substr(1,1));
                            for (int i =0; i< num_book; i++){
                                //cout<<data.substr(2+i*13, 13)<<endl;
                                barcode.push_back(data.substr(2+i*13, 13));
                            }
                            user_id = data.substr(2 + num_book*13, 9);
                            //cout<< user_id<<endl;
                            for(int i = 0; i< num_book; i++){
                                string ans;
                                ans = rent(stoi(user_id), stoi(barcode[i]), &mysql);
                                reply += ans;
                            }
                            
                            new_sock << reply;
                        }
                        else if(task == 2){
                            num_book =stoi(data.substr(1,1));
                            for (int i =0; i< num_book; i++){
                                barcode.push_back(data.substr(2+i*13, 13));
                            }
                            for(int i = 0; i< num_book; i++){
                                string ans;
                                ans = returning(stoi(barcode[i]), &mysql);
                                reply += ans;
                            }
                            new_sock << reply;
                        }
                        else if(task == 3){
                            user_id = data.substr(1, 9);
                            reply = check_status(stoi(user_id), &mysql);

                            new_sock << reply;
                        }
                        mysql_close(&mysql);
                    }
                    connect_count--;
                    close(connectFD);
                }   
                catch ( SocketException& ) {connect_count--;}
            }
            else{
                close(connectFD);
            }
        }
        close(listenFD);
    }
  catch ( SocketException& e )
    {
      std::cout << "Exception was caught:" << e.description() << "\nExiting.\n";
    }
  //close(listenFD);
  return 0;
}